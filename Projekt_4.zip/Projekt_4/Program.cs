﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_4
{
    public abstract class Produkt
    {
        public string Nazwa { get; set; }
        public decimal CenaNetto { get; set; }
        public abstract string KategoriaVAT { get; }
        public abstract string KrajPochodzenia { get; }
        public virtual decimal CenaBrutto => CenaNetto * (1 + GetVatRate());
        protected virtual decimal GetVatRate()
        {
            switch (KategoriaVAT)
            {
                case "A":
                    return 0.23m;
                case "B":
                    return 0.08m;
                case "C":
                    return 0.05m;
                case "D":
                    return 0.0m;
                default:
                    throw new InvalidOperationException("Niepoprawna kategoria VAT");
            }
        }
        public decimal ObliczCenaBrutto()
        {
            return CenaNetto * (1 + GetVatRate());
        }
    }
    public abstract class ProduktSpożywczy : Produkt
    {
        public abstract decimal Kalorie { get; set; }
        public abstract HashSet<string> Alergeny { get; set; }
    }
    public class ProduktSpożywczyPaczka : ProduktSpożywczy
    {
        public override string KategoriaVAT => "B";
        public override string KrajPochodzenia => "Polska";
        public override decimal Kalorie { get; set; }
        public override HashSet<string> Alergeny { get; set; }
        public decimal Waga { get; set; }
    }
    public class ProduktSpożywczyNapój : ProduktSpożywczyPaczka
    {
        public decimal Objętość { get; set; }
        public ProduktSpożywczyNapój()
        {
            Alergeny = new HashSet<string>(); // Inicjalizacja pustego zbioru
        }
    }
    public class Koszyk
    {
        private List<Produkt> produkty;
        public Koszyk()
        {
            produkty = new List<Produkt>();
        }
        public void DodajProdukt(Produkt produkt)
        {
            produkty.Add(produkt);
        }
        public void WyswietlZawartosc()
        {
            Console.WriteLine("Zawartość koszyka:");
            foreach (var produkt in produkty)
            {
                Console.WriteLine($"- Nazwa: {produkt.Nazwa}");
                Console.WriteLine($"  Cena netto: {produkt.CenaNetto}");
                Console.WriteLine($"  Cena brutto: {produkt.ObliczCenaBrutto()}");
                Console.WriteLine($"  Kategoria VAT: {produkt.KategoriaVAT}");
                Console.WriteLine($"  Kraj pochodzenia: {produkt.KrajPochodzenia}");
                if (produkt is ProduktSpożywczy spożywczy)
                {
                    Console.WriteLine($"  Kalorie na 100g: {spożywczy.Kalorie}");
                    Console.WriteLine($"  Alergeny: {string.Join(", ", spożywczy.Alergeny)}");
                }
                if (produkt is ProduktSpożywczyNapój napój)
                {
                    Console.WriteLine($"  Objętość: {napój.Objętość} ml ");
                }
                if (produkt.Nazwa == "Orzechy mix")
                {
                    var orzechyMix = (ProduktSpożywczyPaczka)produkt;
                    Console.WriteLine($"  Waga: {orzechyMix.Waga} g");
                }
                else if (produkt.Nazwa == "Baton proteinowy")
                {
                    var batonProteinowy = (ProduktSpożywczyPaczka)produkt;
                    Console.WriteLine($"  Waga: {batonProteinowy.Waga} g");
                }
                Console.WriteLine();
            }
        }
    }
    public class Program
    {
        public static void Main()
        {
            var koszyk = new Koszyk();
            var woda = new ProduktSpożywczyNapój
            {
                Nazwa = "Woda niegazowana",
                CenaNetto = 2.50m,
                Objętość = 1000,
                Kalorie = 0,
            };
            var batonProteinowy = new ProduktSpożywczyPaczka
            {
                Nazwa = "Baton proteinowy",
                CenaNetto = 5.99m,
                Waga = 50,
                Kalorie = 300,
                Alergeny = new HashSet<string> { "Orzechy", "Soja" }
            };
            var orzechyMix = new ProduktSpożywczyPaczka
            {
                Nazwa = "Orzechy mix",
                CenaNetto = 12.99m,
                Waga = 200,
                Kalorie = 600,
                Alergeny = new HashSet<string> { "Orzechy" }
            };
            koszyk.DodajProdukt(woda);
            koszyk.DodajProdukt(batonProteinowy);
            koszyk.DodajProdukt(orzechyMix);
            koszyk.WyswietlZawartosc();

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
