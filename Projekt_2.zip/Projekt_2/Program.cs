﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_2
{
    public class Prostokat
    {
        private double bokA;
        private double bokB;
        public double BokA
        {
            get { return bokA; }
            set
            {
                if (!double.IsNaN(value) && !double.IsInfinity(value) && value >= 0)
                {
                    bokA = value;
                }
                else
                {
                    throw new ArgumentException("Wartość bokA musi być skończoną, nieujemną liczbą.");
                }
            }
        }
        public double BokB
        {
            get { return bokB; }
            set
            {
                if (!double.IsNaN(value) && !double.IsInfinity(value) && value >= 0)
                {
                    bokB = value;
                }
                else
                {
                    throw new ArgumentException("Wartość bokB musi być skończoną, nieujemną liczbą.");
                }
            }
        }
        public Prostokat(double bokA, double bokB)
        {
            BokA = bokA;
            BokB = bokB;
        }
        private static readonly Dictionary<char, decimal> wysokoscArkusza0 = new Dictionary<char, decimal>
        {
            ['A'] = 1189,
            ['B'] = 1414,
            ['C'] = 1297
        };
        private const double pierwiastekZDwoch = 1.41421356237;
        public static Prostokat ArkuszPapieru(string format)
        {
            if (format == null || format.Length < 2)
            {
                throw new ArgumentException("Format powinien mieć przynajmniej dwa znaki.");
            }

            char X = format[0];
            if (!wysokoscArkusza0.ContainsKey(X))
            {
                throw new ArgumentException($"Niepoprawny klucz: {X}");
            }

            if (!byte.TryParse(format.Substring(1), out byte i))
            {
                throw new ArgumentException("Indeks w formacie powinien być liczbą.");
            }

            decimal bazowaWysokosc = wysokoscArkusza0[X];
            double bokA = (double)(bazowaWysokosc / (decimal)Math.Pow(pierwiastekZDwoch, i));
            double bokB = bokA / pierwiastekZDwoch;
            bokA = Math.Round(bokA);
            bokB = Math.Floor(bokA / pierwiastekZDwoch);
            return new Prostokat(bokA, bokB);
        }

        public override string ToString()
        {
            return $"Prostokąt: bokA = {BokA}, bokB = {BokB}";
        }
    }
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Prostokat prostokat = Prostokat.ArkuszPapieru("A1");
                Console.WriteLine(prostokat);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
