﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    namespace Projekt_5
    {
    public class Macierz<T> : IEquatable<Macierz<T>>
    {
        private readonly T[,] Macierz1;

        public int Rows { get; }
        public int Columns { get; }

        public Macierz(int rows, int columns)
        {
            if (rows <= 0 || columns <= 0)
                throw new ArgumentException("Wymiary muszą być większe od zera.");

            Rows = rows;
            Columns = columns;
            Macierz1 = new T[rows, columns];
        }
        public T this[int row, int column]
        {
            get
            {
                if (row < 0 || row >= Rows || column < 0 || column >= Columns)
                    throw new IndexOutOfRangeException("Indeks poza zakresem.");
                return Macierz1[row, column];
            }
            set
            {
                if (row < 0 || row >= Rows || column < 0 || column >= Columns)
                    throw new IndexOutOfRangeException("Indeks poza zakresem.");
                Macierz1[row, column] = value;
            }
        }
        public static bool operator ==(Macierz<T> left, Macierz<T> right)
        {
            if (ReferenceEquals(left, right))
                return true;
            if (ReferenceEquals(left, null) || ReferenceEquals(right, null))
                return false;
            if (left.Rows != right.Rows || left.Columns != right.Columns)
                return false;

            for (int i = 0; i < left.Rows; i++)
            {
                for (int j = 0; j < left.Columns; j++)
                {
                    if (!EqualityComparer<T>.Default.Equals(left[i, j], right[i, j]))
                        return false;
                }
            }
            return true;
        }
        public static bool operator !=(Macierz<T> left, Macierz<T> right)
        {
            return !(left == right);
        }
        public bool Equals(Macierz<T> other)
        {
            return this == other;
        }
        public override bool Equals(object obj)
        {
            return obj is Macierz<T> matrix && Equals(matrix);
        }
        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 23 + Rows.GetHashCode();
            hash = hash * 23 + Columns.GetHashCode();

            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    hash = hash * 23 + Macierz1[i, j]?.GetHashCode() ?? 0;
                }
            }
            return hash;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Macierz<int> macierz1 = new Macierz<int>(2, 3);
            Macierz<int> macierz2 = new Macierz<int>(2, 3);

            macierz1[0, 0] = 1;
            macierz1[0, 1] = 2;
            macierz1[0, 2] = 3;
            macierz1[1, 0] = 4;
            macierz1[1, 1] = 5;
            macierz1[1, 2] = 6;

            macierz2[0, 0] = 1;
            macierz2[0, 1] = 2;
            macierz2[0, 2] = 3;
            macierz2[1, 0] = 4;
            macierz2[1, 1] = 5;
            macierz2[1, 2] = 6;

            Console.WriteLine(macierz1 == macierz2);

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}