﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_1
{
    public class Osoba
    {
        private string _imie = string.Empty;
        private string _nazwisko = string.Empty;
        public Osoba(string imieNazwisko)
        {
            ImięNazwisko = imieNazwisko;
        }
        public DateTime? DataUrodzenia { get; set; } = null;
        public DateTime? DataŚmierci { get; set; } = null;
        public string Imię
        {
            get { return _imie; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Imię nie może być puste.");
                }
                _imie = value;
            }
        }
        public string Nazwisko
        {
            get { return _nazwisko; }
            set { _nazwisko = value; }
        }
        public string ImięNazwisko
        {
            get { return $"{Imię} {Nazwisko}".Trim(); }
            set
            {
                var parts = value.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length > 0)
                {
                    Imię = parts[0];
                    Nazwisko = parts.Length > 1 ? parts[parts.Length - 1] : string.Empty;
                }
                else
                {
                    Imię = value;
                    Nazwisko = string.Empty;
                }
            }
        }
        public TimeSpan? Wiek
        {
            get
            {
                if (!DataUrodzenia.HasValue)
                {
                    return null;
                }

                var endDate = DataŚmierci ?? DateTime.Now;
                return endDate - DataUrodzenia;
            }
        }
        public static void Main()
        {
            Console.Write("Podaj imię i nazwisko: ");
            string imieNazwisko = Console.ReadLine();

            Osoba osoba = new Osoba(imieNazwisko);

            Console.Write("Podaj datę urodzenia (yyyy-mm-dd): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime dataUrodzenia))
            {
                osoba.DataUrodzenia = dataUrodzenia;
            }
            else
            {
                Console.WriteLine("Nieprawidłowy format daty. Data urodzenia nie została ustawiona.");
            }

            Console.Write("Podaj datę śmierci (yyyy-mm-dd): ");
            string dataSmierciInput = Console.ReadLine();
            if (DateTime.TryParse(dataSmierciInput, out DateTime dataSmierci))
            {
                osoba.DataŚmierci = dataSmierci;
            }
            else if (!string.IsNullOrEmpty(dataSmierciInput))
            {
                Console.WriteLine("Nieprawidłowy format daty. Data śmierci nie została ustawiona.");
            }

            Console.WriteLine($"Imię i nazwisko: {osoba.ImięNazwisko}");
            if (osoba.Wiek.HasValue)
            {
                double wiekLat = osoba.Wiek.Value.TotalDays / 365;
                Console.WriteLine($"Wiek: {Math.Round(wiekLat)} lat");
                if (osoba.DataŚmierci.HasValue)
                {
                    Console.WriteLine($"Data śmierci: {osoba.DataŚmierci.Value:yyyy-mm-dd}");
                }
            }
            else
            {
                Console.WriteLine("Wiek: Brak danych");
            }
            Console.ReadKey();
        }
    }
}
